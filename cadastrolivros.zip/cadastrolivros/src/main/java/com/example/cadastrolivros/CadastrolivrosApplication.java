package com.example.cadastrolivros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastrolivrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastrolivrosApplication.class, args);
	}

}
